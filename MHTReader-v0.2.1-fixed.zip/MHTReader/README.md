# MHT Reader (v0.2)

Offline reader for saved comic pages (`.mht`, `.mhtml`, `.html`). Personal-use app.

## What changed from v0.1
The prototype's parser treated the whole file as text and rewrote `\r\n` to `\n`, which silently corrupts binary
parts (29 of the 37 images in the sample chapter contain raw CRLF byte pairs). v0.2 replaces it with a byte-level
MIME parser (`MhtParser`), and instead of rewriting the HTML it serves archive bytes to the WebView under the
**original URLs** (`shouldInterceptRequest`). Relative URLs, `srcset` and CSS `url()` then resolve natively.

* **Reader mode** – images whose `alt` looks like "page N" are shown as a black, full-width strip (dimensions are
  sniffed from the file headers so lazy loading doesn't collapse; the sample has 800×15000 px WebP strips).
  "Original" shows the saved web page exactly as stored.
* **Offline by construction** – no `INTERNET` permission, WebView network loads blocked, JavaScript off, every
  non-archive URL answered with an empty 404. The source file is only read, never written.
* Recents + reading position (SharedPreferences), tap to show/hide controls, pinch / double-tap zoom.
* "Open with" for `.mht/.mhtml/.html` by MIME type and by file extension.

## Verify the engine (no Android needed)
    tools/run-selftest.sh /path/to/chapter.mht [dump-dir]

## Build the debug APK
Android Studio (Ladybug or newer, JDK 17): open this folder, let it sync (Gradle 8.9 via
`gradle/wrapper/gradle-wrapper.properties`), then *Build ▸ Build APK(s)*.
Output: `app/build/outputs/apk/debug/app-debug.apk`.

No local setup: push this folder to a GitHub repo; `.github/workflows/build-debug-apk.yml` builds the APK and
attaches it as the `MHTReader-debug-apk` artifact (Actions tab).

## Not done yet (deliberately)
Kotlin + Jetpack Compose UI, folder/library scanning, natively-decoded pages for very large strips.
The parser is plain Java with no Android imports, so it stays as-is under a Compose UI.
