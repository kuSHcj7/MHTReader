package com.kush.mhtreader;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** A parsed MHT/MHTML (or plain HTML) file: main HTML plus its embedded resources. No Android dependencies. */
public final class MhtDocument {

    public static final class Resource {
        public final String url;
        public final String mime;
        public final String charset; // may be null
        public final byte[] data;

        public Resource(String url, String mime, String charset, byte[] data) {
            this.url = url; this.mime = mime; this.charset = charset; this.data = data;
        }
    }

    public String title = "";
    public String baseUrl = "";
    public String html = "";
    public final List<Resource> all = new ArrayList<>();
    private final Map<String, Resource> index = new HashMap<>();
    private String readerHtml;
    private boolean readerBuilt;
    public int readerPageCount;

    // ---------------------------------------------------------------- resources

    public void add(Resource r, String... extraKeys) {
        all.add(r);
        putKey(r.url, r);
        for (String k : extraKeys) putKey(k, r);
    }

    private void putKey(String url, Resource r) {
        if (url == null || url.isEmpty()) return;
        String k = key(url);
        if (!index.containsKey(k)) index.put(k, r);
        String d = key(percentDecode(url));
        if (!index.containsKey(d)) index.put(d, r);
    }

    /** Look up a resource by the URL the page (or WebView) requests. Tolerant of fragments, // in paths, %-encoding, http/https. */
    public Resource find(String url) {
        if (url == null || url.isEmpty()) return null;
        String[] tries = {url, percentDecode(url)};
        for (String u : tries) {
            Resource r = index.get(key(u));
            if (r != null) return r;
        }
        for (String u : tries) {
            String k = key(u);
            if (k.startsWith("https://")) { Resource r = index.get("http://" + k.substring(8)); if (r != null) return r; }
            else if (k.startsWith("http://")) { Resource r = index.get("https://" + k.substring(7)); if (r != null) return r; }
        }
        return null;
    }

    private static final Pattern URL_RE = Pattern.compile("^([a-zA-Z][a-zA-Z0-9+.-]*)://([^/?#]*)(.*)$", Pattern.DOTALL);

    static String key(String url) {
        String u = url.trim();
        int h = u.indexOf('#');
        if (h >= 0) u = u.substring(0, h);
        if (u.regionMatches(true, 0, "cid:", 0, 4)) {
            String id = u.substring(4).trim();
            if (id.startsWith("<") && id.endsWith(">")) id = id.substring(1, id.length() - 1);
            return "cid:" + id;
        }
        Matcher m = URL_RE.matcher(u);
        if (!m.matches()) return u;
        String rest = m.group(3);
        int q = rest.indexOf('?');
        String path = q >= 0 ? rest.substring(0, q) : rest;
        String query = q >= 0 ? rest.substring(q) : "";
        while (path.contains("//")) path = path.replace("//", "/");
        return m.group(1).toLowerCase() + "://" + m.group(2).toLowerCase() + path + query;
    }

    static String percentDecode(String s) {
        if (s.indexOf('%') < 0) return s;
        java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '%' && i + 2 < s.length() && isHex(s.charAt(i + 1)) && isHex(s.charAt(i + 2))) {
                o.write(Integer.parseInt(s.substring(i + 1, i + 3), 16));
                i += 2;
            } else {
                byte[] bs = String.valueOf(c).getBytes(java.nio.charset.StandardCharsets.UTF_8);
                o.write(bs, 0, bs.length);
            }
        }
        return new String(o.toByteArray(), java.nio.charset.StandardCharsets.UTF_8);
    }

    private static boolean isHex(char c) { return Character.digit(c, 16) >= 0; }

    public static String resolve(String base, String ref) {
        if (ref == null) return "";
        ref = ref.replaceAll("\\s+", "");
        if (ref.isEmpty()) return "";
        if (ref.matches("^[a-zA-Z][a-zA-Z0-9+.-]*:.*")) return ref;
        if (base == null || base.isEmpty()) return ref;
        try {
            return URI.create(base).resolve(ref).toString();
        } catch (Exception e) {
            return ref;
        }
    }

    // ------------------------------------------------------------- reader mode

    private static final Pattern IMG_TAG = Pattern.compile("(?is)<img\\b[^>]*>");
    private static final Pattern PAGE_ALT = Pattern.compile("(?i)\\bpage\\s*\\d+");

    private static String attr(String tag, String name) {
        Matcher m = Pattern.compile("(?is)(?<![\\w-])" + Pattern.quote(name) + "\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))").matcher(tag);
        if (!m.find()) return null;
        String v = m.group(1) != null ? m.group(1) : m.group(2) != null ? m.group(2) : m.group(3);
        return v.replace("&amp;", "&").replace("&quot;", "\"").replace("&#38;", "&").trim();
    }

    /**
     * Builds a minimal, black, full-width page containing only the comic page images, in document order.
     * Returns null when the document does not look like a comic chapter (caller shows the original page).
     */
    public String buildReaderHtml() {
        if (readerBuilt) return readerHtml;
        readerBuilt = true;
        StringBuilder body = new StringBuilder();
        int n = 0;
        Matcher m = IMG_TAG.matcher(html);
        while (m.find()) {
            String tag = m.group();
            String alt = attr(tag, "alt");
            if (alt == null || !PAGE_ALT.matcher(alt).find()) continue;
            String src = null;
            for (String a : new String[]{"src", "data-src", "data-lazy-src", "data-original"}) {
                String v = attr(tag, a);
                if (v != null && !v.isEmpty() && !v.startsWith("data:")) { src = v; break; }
            }
            if (src == null) continue;
            String abs = resolve(baseUrl, src);
            Resource r = find(abs);
            if (r == null || r.mime == null || !r.mime.startsWith("image/") || r.data == null || r.data.length == 0) continue;
            int[] wh = ImageInfo.sniff(r.data);
            String dataUri = "data:" + r.mime + ";base64," + java.util.Base64.getEncoder().encodeToString(r.data);
            body.append("<img src=\"").append(dataUri).append('"');
            if (wh != null && wh[0] > 0 && wh[1] > 0) {
                body.append(" width=\"").append(wh[0]).append("\" height=\"").append(wh[1])
                    .append("\" style=\"aspect-ratio:").append(wh[0]).append('/').append(wh[1]).append('"');
            }
            body.append(n < 2 ? " loading=\"eager\"" : " loading=\"lazy\"").append(" decoding=\"async\">\n");
            n++;
        }
        readerPageCount = n;
        if (n < 3) { readerHtml = null; return null; }
        readerHtml = "<!doctype html><html><head><meta charset=\"utf-8\">"
                + "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
                + "<style>html,body{margin:0;padding:0;background:#000}"
                + "img{display:block;width:100%;height:auto;margin:0;padding:0;border:0}"
                + ".end{height:120px}</style></head><body>\n" + body + "<div class=\"end\"></div></body></html>";
        return readerHtml;
    }
}
