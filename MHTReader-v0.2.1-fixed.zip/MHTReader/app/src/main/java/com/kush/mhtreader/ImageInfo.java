package com.kush.mhtreader;

/** Tiny header sniffer: image dimensions and MIME type without decoding pixels. No Android dependencies. */
public final class ImageInfo {
    private ImageInfo() {}

    private static int u8(byte[] b, int i) { return b[i] & 0xFF; }
    private static int le16(byte[] b, int i) { return u8(b, i) | (u8(b, i + 1) << 8); }
    private static int le24(byte[] b, int i) { return u8(b, i) | (u8(b, i + 1) << 8) | (u8(b, i + 2) << 16); }
    private static int be16(byte[] b, int i) { return (u8(b, i) << 8) | u8(b, i + 1); }
    private static int be32(byte[] b, int i) { return (u8(b, i) << 24) | (u8(b, i + 1) << 16) | (u8(b, i + 2) << 8) | u8(b, i + 3); }

    public static String mimeOf(byte[] b) {
        if (b == null || b.length < 12) return null;
        if (u8(b, 0) == 0xFF && u8(b, 1) == 0xD8) return "image/jpeg";
        if (u8(b, 0) == 0x89 && b[1] == 'P' && b[2] == 'N' && b[3] == 'G') return "image/png";
        if (b[0] == 'G' && b[1] == 'I' && b[2] == 'F') return "image/gif";
        if (b[0] == 'R' && b[1] == 'I' && b[2] == 'F' && b[3] == 'F' && b[8] == 'W' && b[9] == 'E' && b[10] == 'B' && b[11] == 'P') return "image/webp";
        if (b[0] == 'B' && b[1] == 'M') return "image/bmp";
        return null;
    }

    /** @return {width, height} or null when unknown. */
    public static int[] sniff(byte[] b) {
        String mime = mimeOf(b);
        if (mime == null) return null;
        try {
            switch (mime) {
                case "image/png":
                    return b.length >= 24 ? new int[]{be32(b, 16), be32(b, 20)} : null;
                case "image/gif":
                    return new int[]{le16(b, 6), le16(b, 8)};
                case "image/webp":
                    return webp(b);
                case "image/jpeg":
                    return jpeg(b);
                default:
                    return null;
            }
        } catch (RuntimeException e) {
            return null;
        }
    }

    private static int[] webp(byte[] b) {
        if (b.length < 30) return null;
        if (b[12] == 'V' && b[13] == 'P' && b[14] == '8' && b[15] == ' ') {          // lossy
            return new int[]{le16(b, 26) & 0x3FFF, le16(b, 28) & 0x3FFF};
        }
        if (b[12] == 'V' && b[13] == 'P' && b[14] == '8' && b[15] == 'L') {          // lossless
            int w = 1 + (u8(b, 21) | ((u8(b, 22) & 0x3F) << 8));
            int h = 1 + ((u8(b, 22) >> 6) | (u8(b, 23) << 2) | ((u8(b, 24) & 0x0F) << 10));
            return new int[]{w, h};
        }
        if (b[12] == 'V' && b[13] == 'P' && b[14] == '8' && b[15] == 'X') {          // extended
            return new int[]{1 + le24(b, 24), 1 + le24(b, 27)};
        }
        return null;
    }

    private static int[] jpeg(byte[] b) {
        int i = 2;
        while (i + 9 < b.length) {
            if (u8(b, i) != 0xFF) { i++; continue; }
            int m = u8(b, i + 1);
            if (m == 0xFF) { i++; continue; }
            if (m == 0xD8 || (m >= 0xD0 && m <= 0xD7) || m == 0x01) { i += 2; continue; }
            int len = be16(b, i + 2);
            boolean sof = m >= 0xC0 && m <= 0xCF && m != 0xC4 && m != 0xC8 && m != 0xCC;
            if (sof) return new int[]{be16(b, i + 7), be16(b, i + 5)};
            i += 2 + len;
        }
        return null;
    }
}
