package com.kush.mhtreader;

import java.io.ByteArrayOutputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Byte-level MIME (RFC 2045/2046) parser for MHT/MHTML web archives.
 * Bodies are never round-tripped through String, so binary parts (WebP/JPEG/PNG) stay byte-exact.
 * No Android dependencies, so it can be tested on a plain JVM.
 */
public final class MhtParser {
    private MhtParser() {}

    public static final class ParseException extends Exception {
        private static final long serialVersionUID = 1L;
        public ParseException(String m) { super(m); }
    }

    private static final class Entity {
        final Map<String, String> headers = new HashMap<>();
        String type = "";
        byte[] body = new byte[0];                 // decoded, for leaves
        final List<Entity> children = new ArrayList<>();
        String h(String name) { String v = headers.get(name); return v == null ? "" : v; }
    }

    private static final int MAX_DEPTH = 8;

    public static MhtDocument parse(byte[] raw) throws ParseException {
        if (raw == null || raw.length == 0) throw new ParseException("The file is empty.");
        int off = 0;
        if (raw.length >= 3 && (raw[0] & 0xFF) == 0xEF && (raw[1] & 0xFF) == 0xBB && (raw[2] & 0xFF) == 0xBF) off = 3;
        int first = off;
        while (first < raw.length && (raw[first] == ' ' || raw[first] == '\t' || raw[first] == '\r' || raw[first] == '\n')) first++;
        if (first < raw.length && raw[first] == '<') return parsePlainHtml(raw, first);

        Entity root = parseEntity(raw, off, raw.length, 0);
        List<Entity> leaves = new ArrayList<>();
        collectLeaves(root, leaves);
        if (leaves.isEmpty()) throw new ParseException("No content found. This does not look like an MHT/MHTML archive.");

        // main document: multipart "start" parameter, else first HTML leaf
        Entity main = null;
        String start = param(root.h("content-type"), "start");
        if (start != null) {
            String want = stripAngle(start);
            for (Entity e : leaves) if (stripAngle(e.h("content-id")).equals(want) && isHtml(e.type)) { main = e; break; }
        }
        if (main == null) for (Entity e : leaves) if (isHtml(e.type)) { main = e; break; }
        if (main == null) throw new ParseException("The archive has no HTML page inside.");

        MhtDocument doc = new MhtDocument();
        String snapshot = clean(root.h("snapshot-content-location"));
        String mainLoc = clean(main.h("content-location"));
        doc.baseUrl = !mainLoc.isEmpty() ? MhtDocument.resolve(snapshot, mainLoc) : snapshot;
        if (doc.baseUrl.isEmpty()) doc.baseUrl = "https://mht.invalid/";

        doc.html = decodeHtml(main);
        doc.title = firstNonEmpty(htmlTitle(doc.html), decodeWords(root.h("subject")).trim());

        for (Entity e : leaves) {
            String loc = clean(e.h("content-location"));
            String abs = MhtDocument.resolve(doc.baseUrl, loc);
            String cid = stripAngle(e.h("content-id"));
            String mime = e.type;
            if (mime.isEmpty() || mime.equals("application/octet-stream") || mime.equals("binary/octet-stream")) {
                String sniffed = ImageInfo.mimeOf(e.body);
                if (sniffed != null) mime = sniffed;
            }
            String charset = param(e.h("content-type"), "charset");
            MhtDocument.Resource r = new MhtDocument.Resource(abs, mime.isEmpty() ? "application/octet-stream" : mime, charset, e.body);
            if (cid.isEmpty()) doc.add(r); else doc.add(r, "cid:" + cid);
        }
        return doc;
    }

    private static MhtDocument parsePlainHtml(byte[] raw, int start) {
        MhtDocument doc = new MhtDocument();
        byte[] b = java.util.Arrays.copyOfRange(raw, start, raw.length);
        doc.html = decodeText(b, null);
        doc.title = htmlTitle(doc.html);
        doc.baseUrl = "https://mht.invalid/";
        return doc;
    }

    // ------------------------------------------------------------------ MIME

    private static Entity parseEntity(byte[] d, int start, int end, int depth) throws ParseException {
        Entity e = new Entity();
        int pos = start;
        String foldTarget = null;
        int bodyStart = end;
        boolean sawBlank = false;
        while (pos < end) {
            int eol = indexOf(d, (byte) '\n', pos, end);
            int lineEnd = eol < 0 ? end : eol;
            int next = eol < 0 ? end : eol + 1;
            int trim = lineEnd;
            if (trim > pos && d[trim - 1] == '\r') trim--;
            if (trim == pos) { bodyStart = next; sawBlank = true; break; }
            String line = new String(d, pos, trim - pos, StandardCharsets.ISO_8859_1);
            if ((line.charAt(0) == ' ' || line.charAt(0) == '\t') && foldTarget != null) {
                e.headers.put(foldTarget, e.headers.get(foldTarget) + " " + line.trim());
            } else {
                foldTarget = null;
                int c = line.indexOf(':');
                if (c > 0) {
                    String name = line.substring(0, c).trim().toLowerCase(Locale.ROOT);
                    if (!e.headers.containsKey(name)) {          // first occurrence wins
                        e.headers.put(name, line.substring(c + 1).trim());
                        foldTarget = name;
                    }
                }
            }
            pos = next;
        }
        if (!sawBlank) bodyStart = end;

        String ct = e.h("content-type");
        e.type = baseType(ct);
        String boundary = param(ct, "boundary");
        if (e.type.startsWith("multipart/") && boundary != null && !boundary.isEmpty()) {
            if (depth >= MAX_DEPTH) throw new ParseException("Archive is nested too deeply.");
            for (int[] r : splitMultipart(d, bodyStart, end, boundary)) e.children.add(parseEntity(d, r[0], r[1], depth + 1));
        } else {
            e.body = decodeBody(d, bodyStart, end, e.h("content-transfer-encoding"));
        }
        return e;
    }

    private static void collectLeaves(Entity e, List<Entity> out) {
        if (e.children.isEmpty()) {
            if (!e.type.startsWith("multipart/")) out.add(e);
            return;
        }
        for (Entity c : e.children) collectLeaves(c, out);
    }

    /** Returns [start,end) ranges of each part, with the CRLF/LF that precedes the next delimiter removed. */
    static List<int[]> splitMultipart(byte[] d, int from, int end, String boundary) {
        byte[] delim = ("--" + boundary).getBytes(StandardCharsets.ISO_8859_1);
        List<int[]> parts = new ArrayList<>();
        int pos = indexOfDelimiter(d, delim, from, end, from);
        while (pos >= 0) {
            int after = pos + delim.length;
            if (after + 1 < end && d[after] == '-' && d[after + 1] == '-') break; // closing delimiter
            int eol = indexOf(d, (byte) '\n', after, end);
            if (eol < 0) break;
            int partStart = eol + 1;
            int next = indexOfDelimiter(d, delim, partStart, end, from);
            int partEnd = next < 0 ? end : next;
            if (next >= 0) {
                if (partEnd > partStart && d[partEnd - 1] == '\n') partEnd--;
                if (partEnd > partStart && d[partEnd - 1] == '\r') partEnd--;
            }
            parts.add(new int[]{partStart, partEnd});
            pos = next;
        }
        return parts;
    }

    private static int indexOfDelimiter(byte[] d, byte[] delim, int from, int end, int bodyStart) {
        int limit = end - delim.length;
        for (int i = from; i <= limit; i++) {
            if (d[i] != '-') continue;
            if (i != bodyStart && d[i - 1] != '\n') continue;
            boolean ok = true;
            for (int k = 1; k < delim.length; k++) if (d[i + k] != delim[k]) { ok = false; break; }
            if (!ok) continue;
            int a = i + delim.length;
            if (a >= end) return i;
            byte c = d[a];
            if (c == '-' || c == '\r' || c == '\n' || c == ' ' || c == '\t') return i;
        }
        return -1;
    }

    private static int indexOf(byte[] d, byte b, int from, int end) {
        for (int i = from; i < end; i++) if (d[i] == b) return i;
        return -1;
    }

    // -------------------------------------------------------- transfer decoding

    private static byte[] decodeBody(byte[] d, int s, int e, String cte) {
        String enc = cte == null ? "" : cte.trim().toLowerCase(Locale.ROOT);
        if (s >= e) return new byte[0];
        if (enc.equals("base64")) return decodeBase64(d, s, e);
        if (enc.equals("quoted-printable")) return decodeQuotedPrintable(d, s, e);
        return java.util.Arrays.copyOfRange(d, s, e);   // 7bit / 8bit / binary: byte-exact
    }

    private static byte[] decodeBase64(byte[] d, int s, int e) {
        ByteArrayOutputStream clean = new ByteArrayOutputStream(e - s);
        for (int i = s; i < e; i++) {
            byte c = d[i];
            if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '+' || c == '/') clean.write(c);
            else if (c == '=') break;
        }
        byte[] b = clean.toByteArray();
        int usable = b.length - (b.length % 4 == 1 ? 1 : 0);   // a lone trailing sextet carries no data
        try {
            return Base64.getDecoder().decode(new String(b, 0, usable, StandardCharsets.ISO_8859_1)); // padding optional
        } catch (IllegalArgumentException ex) {
            return new byte[0];
        }
    }

    private static byte[] decodeQuotedPrintable(byte[] d, int s, int e) {
        ByteArrayOutputStream o = new ByteArrayOutputStream(e - s);
        for (int i = s; i < e; i++) {
            byte c = d[i];
            if (c == '=') {
                if (i + 1 < e && d[i + 1] == '\n') { i += 1; continue; }
                if (i + 2 < e && d[i + 1] == '\r' && d[i + 2] == '\n') { i += 2; continue; }
                if (i + 2 < e) {
                    int hi = Character.digit((char) d[i + 1], 16), lo = Character.digit((char) d[i + 2], 16);
                    if (hi >= 0 && lo >= 0) { o.write(hi * 16 + lo); i += 2; continue; }
                }
            }
            o.write(c);
        }
        return o.toByteArray();
    }

    // -------------------------------------------------------------- text helpers

    private static boolean isHtml(String t) { return t.equals("text/html") || t.equals("application/xhtml+xml"); }

    private static String decodeHtml(Entity e) {
        return decodeText(e.body, param(e.h("content-type"), "charset"));
    }

    static String decodeText(byte[] b, String declared) {
        if (b.length >= 3 && (b[0] & 0xFF) == 0xEF && (b[1] & 0xFF) == 0xBB && (b[2] & 0xFF) == 0xBF)
            return new String(b, 3, b.length - 3, StandardCharsets.UTF_8);
        if (b.length >= 2 && (b[0] & 0xFF) == 0xFF && (b[1] & 0xFF) == 0xFE) return new String(b, 2, b.length - 2, StandardCharsets.UTF_16LE);
        if (b.length >= 2 && (b[0] & 0xFF) == 0xFE && (b[1] & 0xFF) == 0xFF) return new String(b, 2, b.length - 2, StandardCharsets.UTF_16BE);
        String cs = declared;
        if (cs == null || cs.isEmpty()) {
            String head = new String(b, 0, Math.min(b.length, 4096), StandardCharsets.ISO_8859_1);
            Matcher m = Pattern.compile("(?i)charset\\s*=\\s*[\"']?([A-Za-z0-9_\\-:.]+)").matcher(head);
            if (m.find()) cs = m.group(1);
        }
        Charset c = StandardCharsets.UTF_8;
        if (cs != null) { try { c = Charset.forName(cs.trim()); } catch (Exception ignored) { } }
        return new String(b, c);
    }

    private static String htmlTitle(String html) {
        Matcher m = Pattern.compile("(?is)<title[^>]*>(.*?)</title>").matcher(html);
        if (!m.find()) return "";
        return unescape(m.group(1)).replaceAll("\\s+", " ").trim();
    }

    static String unescape(String s) {
        s = s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&#39;", "'").replace("&apos;", "'").replace("&nbsp;", " ");
        Matcher m = Pattern.compile("&#(x?)([0-9a-fA-F]+);").matcher(s);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String rep;
            try { rep = new String(Character.toChars(Integer.parseInt(m.group(2), m.group(1).isEmpty() ? 10 : 16))); }
            catch (Exception ex) { rep = m.group(); }
            m.appendReplacement(sb, Matcher.quoteReplacement(rep));
        }
        m.appendTail(sb);
        return sb.toString().replace("&amp;", "&");
    }

    /** RFC 2047 encoded-words in headers such as Subject. */
    static String decodeWords(String s) {
        if (s == null || !s.contains("=?")) return s == null ? "" : s;
        s = s.replaceAll("(\\?=)\\s+(=\\?)", "$1$2");
        Matcher m = Pattern.compile("=\\?([^?]+)\\?([bBqQ])\\?([^?]*)\\?=").matcher(s);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String rep = m.group();
            try {
                Charset cs = Charset.forName(m.group(1));
                byte[] bytes;
                if (m.group(2).equalsIgnoreCase("B")) bytes = Base64.getMimeDecoder().decode(m.group(3));
                else {
                    byte[] q = m.group(3).replace('_', ' ').getBytes(StandardCharsets.ISO_8859_1);
                    bytes = decodeQuotedPrintable(q, 0, q.length);
                }
                rep = new String(bytes, cs);
            } catch (Exception ignored) { }
            m.appendReplacement(sb, Matcher.quoteReplacement(rep));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    static String baseType(String ct) {
        if (ct == null) return "";
        int i = ct.indexOf(';');
        return (i >= 0 ? ct.substring(0, i) : ct).trim().toLowerCase(Locale.ROOT);
    }

    static String param(String header, String name) {
        if (header == null) return null;
        Matcher m = Pattern.compile("(?i)(?:^|[;\\s])" + Pattern.quote(name) + "\\s*=\\s*(?:\"([^\"]*)\"|([^;\\s]+))").matcher(header);
        if (!m.find()) return null;
        return m.group(1) != null ? m.group(1) : m.group(2);
    }

    private static String stripAngle(String s) {
        s = s == null ? "" : s.trim();
        if (s.startsWith("<") && s.endsWith(">") && s.length() >= 2) s = s.substring(1, s.length() - 1);
        return s;
    }

    private static String clean(String s) { return s == null ? "" : s.replaceAll("\\s+", ""); }

    private static String firstNonEmpty(String a, String b) { return a != null && !a.isEmpty() ? a : (b == null ? "" : b); }
}
