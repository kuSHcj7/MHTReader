package com.kush.mhtreader;

import java.io.File;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Plain-JVM check of the parser against a real MHT file. Usage: java com.kush.mhtreader.MhtSelfTest <file> [dumpDir] */
public class MhtSelfTest {
    static int fails = 0;
    static void check(boolean ok, String msg) { System.out.println((ok ? "PASS  " : "FAIL  ") + msg); if (!ok) fails++; }
    static String sha(byte[] b) throws Exception {
        StringBuilder sb = new StringBuilder();
        for (byte x : MessageDigest.getInstance("SHA-256").digest(b)) sb.append(String.format("%02x", x));
        return sb.toString();
    }

    public static void main(String[] a) throws Exception {
        byte[] raw = Files.readAllBytes(new File(a[0]).toPath());
        long t0 = System.nanoTime();
        MhtDocument d = MhtParser.parse(raw);
        long ms = (System.nanoTime() - t0) / 1_000_000;
        System.out.println("parsed in " + ms + " ms, resources=" + d.all.size() + ", title=" + d.title + ", base=" + d.baseUrl);

        check(d.all.size() == 43, "43 leaf parts (1 html + 37 images + 5 css)");
        check(d.title.equals("Solo Max-Level Newbie Chapter 218 - Asura Scans"), "title from <title>");
        check(d.html.startsWith("<!DOCTYPE html>") && d.html.contains("chapter page 1"), "main HTML decoded");
        check(d.baseUrl.endsWith("/chapter/218"), "base URL = main Content-Location");

        // every <img src> / stylesheet href in the page should resolve inside the archive
        int imgs = 0, resolved = 0;
        Matcher m = Pattern.compile("(?is)<img\\b[^>]*?\\ssrc=\"([^\"]+)\"").matcher(d.html);
        while (m.find()) { imgs++; if (d.find(MhtDocument.resolve(d.baseUrl, m.group(1).replace("&amp;", "&"))) != null) resolved++; }
        System.out.println("<img src> resolved: " + resolved + "/" + imgs);
        check(resolved == imgs && imgs > 0, "all <img src> resolve to embedded resources");
        int css = 0, cssOk = 0;
        m = Pattern.compile("(?is)<link[^>]+rel=\"stylesheet\"[^>]+href=\"([^\"]+)\"").matcher(d.html);
        while (m.find()) { css++; if (d.find(m.group(1)) != null) cssOk++; }
        check(css == 5 && cssOk == 5, "5/5 stylesheets resolve (" + cssOk + "/" + css + ")");

        // tolerant lookups
        check(d.find("https://gg.asuracomic.net/storage/profile_images/364890/53c7ddcf-f3c3-44aa-a49a-bd7e930b3563.jpeg") != null,
              "double-slash Content-Location matches single-slash request");
        check(d.find("http://asuracomic.net/images/logo.webp#x") != null, "http/https + fragment tolerant");
        check(d.find("https://example.com/nope.png") == null, "unknown URL -> null (stays offline)");

        // reader mode
        String rh = d.buildReaderHtml();
        check(rh != null && d.readerPageCount == 13, "reader mode found 13 comic pages (got " + d.readerPageCount + ")");
        int[][] want = {{1200, 800}, {800, 15000}, {800, 14850}, {800, 15000}, {800, 12785}, {800, 14195}};
        Matcher im = Pattern.compile("width=\"(\\d+)\" height=\"(\\d+)\"").matcher(rh == null ? "" : rh);
        int idx = 0; boolean dimsOk = true;
        int[][] expectedAll = {{1200,800},{800,15000},{800,12785},{800,15000},{800,14850},{800,15000},{800,14195},{800,14860},{800,14340},{800,12830},{800,13685},{800,14390},{800,5065}};
        while (im.find()) { if (idx < 13 && (Integer.parseInt(im.group(1)) != expectedAll[idx][0] || Integer.parseInt(im.group(2)) != expectedAll[idx][1])) dimsOk = false; idx++; }
        check(idx == 13 && dimsOk, "sniffed WebP dimensions match Pillow for all 13 pages, in reading order");

        // byte-exactness: hashes printed for comparison with the Python extraction
        if (a.length > 1) {
            File dir = new File(a[1]); dir.mkdirs();
            StringBuilder manifest = new StringBuilder();
            for (MhtDocument.Resource r : d.all) manifest.append(sha(r.data)).append("  ").append(r.mime).append("  ").append(r.data.length).append("  ").append(r.url).append('\n');
            Files.write(new File(dir, "java-manifest.txt").toPath(), manifest.toString().getBytes("UTF-8"));
            Files.write(new File(dir, "reader.html").toPath(), rh.getBytes("UTF-8"));
            int i = 0;
            for (MhtDocument.Resource r : d.all) if (r.url.contains("/conversions/") && r.url.contains("3433")) {
                Files.write(new File(dir, r.url.substring(r.url.lastIndexOf('/') + 1)).toPath(), r.data); i++;
            }
            System.out.println("dumped " + i + " page images + manifest to " + dir);
        }
        System.out.println(fails == 0 ? "\nALL CHECKS PASSED" : "\n" + fails + " CHECK(S) FAILED");
        System.exit(fails == 0 ? 0 : 1);
    }
}
