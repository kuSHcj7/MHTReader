#!/usr/bin/env bash
# Verifies the MHT engine on a plain JVM (JDK 17+), no Android needed.
# Usage: tools/run-selftest.sh path/to/comic.mht [dump-dir]
set -euo pipefail
cd "$(dirname "$0")/.."
OUT=$(mktemp -d)
javac -d "$OUT" app/src/main/java/com/kush/mhtreader/{ImageInfo,MhtDocument,MhtParser}.java tools/MhtSelfTest.java
java -cp "$OUT" com.kush.mhtreader.MhtSelfTest "$@"
