package com.kush.mhtreader;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * MHT Reader. Single activity, no third-party dependencies.
 * The file is parsed locally; the WebView is only ever fed bytes from the archive (see LocalClient),
 * and the app has no INTERNET permission, so nothing can leave the device.
 */
public class MainActivity extends Activity {
    private static final int REQ_PICK = 42;
    private static final long MAX_BYTES = 512L * 1024 * 1024;
    private static final int MAX_RECENTS = 20;

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;

    private FrameLayout root;
    private LinearLayout home;
    private FrameLayout reader;
    private WebView web;
    private LinearLayout bar;
    private TextView barTitle, barMode, homeStatus;
    private ListView recentList;
    private RecentsAdapter adapter;

    private volatile MhtDocument doc;
    private String currentUri = "";
    private boolean readerMode;
    private boolean controlsVisible;
    private int topInset, bottomInset;
    private float pendingRestore = -1f;

    // ------------------------------------------------------------------ lifecycle

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("mht", MODE_PRIVATE);
        getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.BLACK));
        edgeToEdge();
        buildUi();
        showHome();
        handleIntent(getIntent());
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    @Override protected void onPause() { savePosition(); super.onPause(); }

    @Override protected void onDestroy() {
        super.onDestroy();
        io.shutdownNow();
        if (web != null) { web.stopLoading(); web.destroy(); }
    }

    @SuppressWarnings("deprecation")
    @Override public void onBackPressed() {
        if (reader.getVisibility() == View.VISIBLE) { showHome(); } else { super.onBackPressed(); }
    }

    // ------------------------------------------------------------------------ UI

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + .5f); }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif" + (bold ? "-medium" : "-light"), Typeface.NORMAL));
        return t;
    }

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        // ---- Home / library
        home = new LinearLayout(this);
        home.setOrientation(LinearLayout.VERTICAL);
        home.setPadding(dp(28), dp(24), dp(28), dp(16));
        TextView title = text("MHT Reader", 34, Color.WHITE, false);
        title.setPadding(0, dp(28), 0, dp(4));
        TextView sub = text("Offline reading for saved comics.", 15, 0xFF8C8C8C, false);
        homeStatus = text("", 14, 0xFF8C8C8C, false);
        homeStatus.setPadding(0, dp(12), 0, 0);
        TextView open = text("Open a file", 16, Color.BLACK, true);
        open.setGravity(Gravity.CENTER);
        GradientDrawable pill = new GradientDrawable();
        pill.setColor(0xFFF2F2F2); pill.setCornerRadius(dp(26));
        open.setBackground(pill);
        open.setOnClickListener(v -> pick());
        LinearLayout.LayoutParams olp = new LinearLayout.LayoutParams(-1, dp(52));
        olp.topMargin = dp(32);
        TextView recentLabel = text("RECENT", 12, 0xFF6E6E6E, true);
        recentLabel.setLetterSpacing(0.12f);
        recentLabel.setPadding(0, dp(40), 0, dp(8));
        recentList = new ListView(this);
        recentList.setDivider(new android.graphics.drawable.ColorDrawable(0xFF1F1F1F));
        recentList.setDividerHeight(1);
        recentList.setSelector(android.R.color.transparent);
        adapter = new RecentsAdapter();
        recentList.setAdapter(adapter);
        recentList.setOnItemClickListener((p, v, pos, id) -> {
            JSONObject o = adapter.get(pos);
            if (o != null) openUri(Uri.parse(o.optString("uri")), false);
        });
        home.addView(title); home.addView(sub); home.addView(open, olp); home.addView(homeStatus);
        home.addView(recentLabel); home.addView(recentList, new LinearLayout.LayoutParams(-1, 0, 1));

        // ---- Reader
        reader = new FrameLayout(this);
        reader.setBackgroundColor(Color.BLACK);
        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(false);              // saved pages are untrusted; comics don't need scripts
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setBlockNetworkLoads(true);
        s.setDomStorageEnabled(false);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        web.setVerticalScrollBarEnabled(false);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setWebViewClient(new LocalClient());
        final GestureDetector taps = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onSingleTapConfirmed(MotionEvent e) { toggleControls(); return true; }
        });
        web.setOnTouchListener((v, ev) -> { taps.onTouchEvent(ev); return false; });
        reader.addView(web, new FrameLayout.LayoutParams(-1, -1));

        bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(0xCC000000);
        TextView back = text("‹", 30, Color.WHITE, false);
        back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v -> showHome());
        barTitle = text("", 15, Color.WHITE, true);
        barTitle.setSingleLine(true);
        barTitle.setEllipsize(android.text.TextUtils.TruncateAt.END);
        barMode = text("Original", 14, 0xFFBDBDBD, true);
        barMode.setGravity(Gravity.CENTER);
        barMode.setPadding(dp(16), 0, dp(20), 0);
        barMode.setOnClickListener(v -> toggleMode());
        bar.addView(back, new LinearLayout.LayoutParams(dp(56), dp(52)));
        bar.addView(barTitle, new LinearLayout.LayoutParams(0, dp(52), 1));
        bar.addView(barMode, new LinearLayout.LayoutParams(-2, dp(52)));
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        bar.setVisibility(View.GONE);
        reader.addView(bar, blp);

        root.addView(home, new FrameLayout.LayoutParams(-1, -1));
        root.addView(reader, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        root.setOnApplyWindowInsetsListener((v, insets) -> {
            topInset = insets.getSystemWindowInsetTop();
            bottomInset = insets.getSystemWindowInsetBottom();
            home.setPadding(dp(28), dp(24) + topInset, dp(28), dp(16) + bottomInset);
            bar.setPadding(0, topInset, 0, 0);
            return insets;
        });
    }

    private void showHome() {
        savePosition();
        reader.setVisibility(View.GONE);
        home.setVisibility(View.VISIBLE);
        web.stopLoading();
        web.loadUrl("about:blank");
        doc = null; currentUri = "";
        adapter.reload();
        setSystemBars(true);
        homeStatus.setText("");
    }

    private void showReader() {
        home.setVisibility(View.GONE);
        reader.setVisibility(View.VISIBLE);
        controlsVisible = false;
        bar.setVisibility(View.GONE);
        setSystemBars(false);
    }

    private void toggleControls() {
        controlsVisible = !controlsVisible;
        if (controlsVisible) {
            bar.setAlpha(0f); bar.setVisibility(View.VISIBLE);
            bar.animate().alpha(1f).setDuration(180).start();
        } else {
            bar.animate().alpha(0f).setDuration(160).withEndAction(() -> { if (!controlsVisible) bar.setVisibility(View.GONE); }).start();
        }
        setSystemBars(controlsVisible);
    }

    private void toggleMode() {
        MhtDocument d = doc;
        if (d == null || d.buildReaderHtml() == null) return;
        readerMode = !readerMode;
        pendingRestore = -1f;
        render(d);
    }

    // ------------------------------------------------------------- system bars

    @SuppressWarnings("deprecation")
    private void edgeToEdge() {
        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false);
        } else {
            w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
    }

    @SuppressWarnings("deprecation")
    private void setSystemBars(boolean visible) {
        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = w.getInsetsController();
            if (c == null) return;
            c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            c.setSystemBarsAppearance(0, WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
            if (visible) c.show(WindowInsets.Type.systemBars()); else c.hide(WindowInsets.Type.systemBars());
        } else {
            int base = View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
            w.getDecorView().setSystemUiVisibility(visible ? base
                    : base | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    // ------------------------------------------------------------------ opening

    private void pick() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");   // .mht has no reliable MIME type across devices
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, REQ_PICK);
    }

    @SuppressWarnings("deprecation")
    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_PICK && res == RESULT_OK && data != null && data.getData() != null) openUri(data.getData(), true);
    }

    private void handleIntent(Intent i) {
        if (i == null) return;
        if (Intent.ACTION_VIEW.equals(i.getAction()) && i.getData() != null) openUri(i.getData(), false);
    }

    private String displayName(Uri u) {
        try (Cursor c = getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) { String n = c.getString(0); if (n != null) return n; }
        } catch (Exception ignored) { }
        String p = u.getLastPathSegment();
        return p == null ? "Untitled" : p.substring(p.lastIndexOf('/') + 1);
    }

    private void openUri(final Uri uri, final boolean fromPicker) {
        savePosition();
        homeStatus.setText("Opening…");
        try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
        catch (Exception ignored) { /* VIEW intents often carry only a one-shot grant; recents may then need re-picking */ }
        final String name = displayName(uri);
        io.execute(() -> {
            MhtDocument parsed = null; String error = null;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) throw new java.io.IOException("Could not open the file.");
                ByteArrayOutputStream out = new ByteArrayOutputStream(1 << 20);
                byte[] buf = new byte[1 << 16]; int n; long total = 0;
                while ((n = in.read(buf)) != -1) {
                    total += n;
                    if (total > MAX_BYTES) throw new java.io.IOException("File is larger than 512 MB.");
                    out.write(buf, 0, n);
                }
                parsed = MhtParser.parse(out.toByteArray());
                parsed.buildReaderHtml();
            } catch (SecurityException e) {
                error = "Android no longer allows access to this file. Open it again from the picker.";
            } catch (Throwable e) {
                error = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
            }
            final MhtDocument result = parsed; final String err = error;
            runOnUiThread(() -> {
                if (isDestroyed()) return;
                if (err != null || result == null) {
                    homeStatus.setText("");
                    if (reader.getVisibility() != View.VISIBLE) showHome();
                    Toast.makeText(this, name + ": " + err, Toast.LENGTH_LONG).show();
                    return;
                }
                doc = result;
                currentUri = uri.toString();
                if (result.title.isEmpty()) result.title = name;
                rememberRecent(uri.toString(), name, result.title);
                readerMode = result.buildReaderHtml() != null;
                pendingRestore = prefs.getFloat("pos:" + currentUri + (readerMode ? ":r" : ":o"), -1f);
                showReader();
                render(result);
            });
        });
    }

    private void render(MhtDocument d) {
        barTitle.setText(d.title);
        boolean canToggle = d.buildReaderHtml() != null;
        barMode.setVisibility(canToggle ? View.VISIBLE : View.GONE);
        barMode.setText(readerMode ? "Original" : "Reader");
        String html = readerMode ? d.buildReaderHtml() : d.html;
        web.loadDataWithBaseURL(d.baseUrl, html, "text/html", "UTF-8", null);
    }

    // ---------------------------------------------------------- WebView content

    /** Serves archive bytes for the original URLs the page asks for; everything else is answered with an empty 404. */
    private final class LocalClient extends WebViewClient {
        @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            MhtDocument d = doc;
            if (d != null) {
                MhtDocument.Resource res = d.find(r.getUrl().toString());
                if (res != null) {
                    boolean textual = res.mime.startsWith("text/") || res.mime.contains("javascript") || res.mime.contains("xml") || res.mime.contains("json");
                    String enc = res.charset != null ? res.charset : (textual ? "utf-8" : null);
                    Map<String, String> headers = new HashMap<>();
                    headers.put("Access-Control-Allow-Origin", "*");
                    return new WebResourceResponse(res.mime, enc, 200, "OK", headers, new ByteArrayInputStream(res.data));
                }
            }
            return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", Collections.<String, String>emptyMap(), new ByteArrayInputStream(new byte[0]));
        }

        @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return true; } // links stay inert

        @Override public void onPageFinished(WebView v, String url) {
            final float frac = pendingRestore;
            if (frac > 0f) {
                pendingRestore = -1f;
                v.postDelayed(() -> v.scrollTo(0, (int) (frac * totalHeightPx())), 350);
            }
        }
    }

    // ------------------------------------------------- reading position & recents

    private int totalHeightPx() { return (int) (web.getContentHeight() * getResources().getDisplayMetrics().density); }

    private void savePosition() {
        if (currentUri.isEmpty() || web == null || reader == null || reader.getVisibility() != View.VISIBLE) return;
        int total = totalHeightPx();
        if (total <= 0) return;
        float frac = Math.max(0f, Math.min(1f, web.getScrollY() / (float) total));
        prefs.edit().putFloat("pos:" + currentUri + (readerMode ? ":r" : ":o"), frac).apply();
    }

    private void rememberRecent(String uri, String name, String title) {
        try {
            JSONArray old = new JSONArray(prefs.getString("recents", "[]"));
            JSONArray next = new JSONArray();
            JSONObject me = new JSONObject();
            me.put("uri", uri); me.put("name", name); me.put("title", title); me.put("ts", System.currentTimeMillis());
            next.put(me);
            for (int i = 0; i < old.length() && next.length() < MAX_RECENTS; i++)
                if (!uri.equals(old.getJSONObject(i).optString("uri"))) next.put(old.getJSONObject(i));
            prefs.edit().putString("recents", next.toString()).apply();
        } catch (Exception ignored) { }
    }

    private final class RecentsAdapter extends BaseAdapter {
        private JSONArray items = new JSONArray();
        RecentsAdapter() { reload(); }
        void reload() {
            try { items = new JSONArray(prefs.getString("recents", "[]")); } catch (Exception e) { items = new JSONArray(); }
            notifyDataSetChanged();
        }
        JSONObject get(int i) { return items.optJSONObject(i); }
        @Override public int getCount() { return items.length(); }
        @Override public Object getItem(int i) { return get(i); }
        @Override public long getItemId(int i) { return i; }
        @Override public View getView(int i, View convert, ViewGroup parent) {
            JSONObject o = get(i);
            LinearLayout row = new LinearLayout(MainActivity.this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(0, dp(16), 0, dp(16));
            String title = o == null ? "" : o.optString("title", o.optString("name"));
            TextView t = text(title, 16, Color.WHITE, false);
            t.setSingleLine(true); t.setEllipsize(android.text.TextUtils.TruncateAt.END);
            float p = o == null ? -1 : Math.max(prefs.getFloat("pos:" + o.optString("uri") + ":r", -1f), prefs.getFloat("pos:" + o.optString("uri") + ":o", -1f));
            TextView s = text(p > 0.01f ? "Resume · " + Math.round(p * 100) + "%" : "Not started", 13, 0xFF6E6E6E, false);
            row.addView(t); row.addView(s);
            return row;
        }
    }
}
